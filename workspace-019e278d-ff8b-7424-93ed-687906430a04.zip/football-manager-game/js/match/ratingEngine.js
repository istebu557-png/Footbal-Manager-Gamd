import { clamp } from '../core/utils.js';
export function effectiveRating(player) {
  const energyFactor = clamp(player.energy, 1, 110) / 100;
  const formFactor = clamp(player.form, 4, 10) / 10;
  const moraleFactor = clamp(player.morale, 0, 100) / 100;
  const injuryPenalty = player.injuredWeeks > 0 ? 0.75 : 1;
  return Math.round((player.overall * .62 + player.overall * energyFactor * .23 + player.overall * formFactor * .10 + player.overall * moraleFactor * .05) * injuryPenalty);
}
