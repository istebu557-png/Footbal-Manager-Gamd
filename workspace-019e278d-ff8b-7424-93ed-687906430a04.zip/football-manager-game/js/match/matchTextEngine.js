import { choice } from '../core/utils.js';
export function normalEvent(minute, attackingTeam, player) {
  const texts = [
    `${attackingTeam.name} pas temposunu artırdı. ${player?.name || 'Orta saha'} ceza sahası çevresinde boşluk arıyor.`,
    `${player?.name || attackingTeam.name} çizgiye indi, savunma son anda araya girdi.`,
    `${attackingTeam.name} geçiş hücumuna çıktı ancak final pası isabetli olmadı.`,
    `${player?.name || 'Bir oyuncu'} uzaktan denedi, top kalecide kaldı.`,
    `${attackingTeam.name} rakip yarı sahaya yerleşti; tribünler baskıyı hissediyor.`
  ];
  return { minute, type: 'normal', text: choice(texts) };
}
export function goalEvent(minute, team, scorer, assister) {
  const texts = [
    `GOL! ${scorer.name} doğru yerde bekledi ve topu ağlara gönderdi${assister ? `. Asist ${assister.name}.` : '.'}`,
    `GOL! ${team.name} baskının karşılığını aldı. ${scorer.name} net bitirdi${assister ? `, pası veren ${assister.name}.` : '.'}`,
    `GOL! ${scorer.name} kaleciyle karşı karşıya kaldı, soğukkanlı vuruşla skoru değiştirdi.`
  ];
  return { minute, type: 'goal', teamId: team.id, playerId: scorer.id, text: choice(texts) };
}
export function fatigueEvent(minute, team) {
  return { minute, type: 'normal', text: `${team.name} cephesinde yorgunluk belirtileri başladı. Baskı seviyesi ve enerji yönetimi maçın son bölümünü belirleyebilir.` };
}
export function injuryEvent(minute, player) {
  return { minute, type: 'injury', playerId: player.id, text: `${player.name} yerde kaldı. Sağlık ekibi oyuna girdi; oyuncu birkaç hafta kaçırabilir.` };
}
