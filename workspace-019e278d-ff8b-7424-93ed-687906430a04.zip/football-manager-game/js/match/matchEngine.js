import { avg, choice, clamp, playersByTeam, rand, teamById } from '../core/utils.js';
import { effectiveRating } from './ratingEngine.js';
import { normalizeLineup } from '../league/lineupSystem.js';
import { drainPlayerEnergy, tacticProfiles } from './energyEngine.js';
import { goalEvent, normalEvent, fatigueEvent, injuryEvent } from './matchTextEngine.js';

function selectLineup(state, teamId, players) {
  const normalized = normalizeLineup(players, state.lineups?.[teamId]);
  const chosen = normalized.map(id => players.find(p => p.id === id)).filter(Boolean).filter(p => p.injuredWeeks <= 0);
  if (chosen.length >= 11) return chosen.slice(0, 11);
  const extras = players.filter(p => p.injuredWeeks <= 0 && !chosen.some(c => c.id === p.id)).sort((a,b) => effectiveRating(b) - effectiveRating(a));
  return [...chosen, ...extras].slice(0, 11);
}
function teamStrength(lineup) { return avg(lineup.map(effectiveRating)); }
function attackingPlayer(lineup) {
  const attackers = lineup.filter(p => ['ST','LW','RW','W','AM'].includes(p.position));
  return choice(attackers.length ? attackers : lineup);
}
function assistPlayer(lineup, scorer) {
  const creators = lineup.filter(p => p.id !== scorer.id && ['AM','CM','RW','LW','W','FB'].includes(p.position));
  return choice(creators.length ? creators : lineup.filter(p => p.id !== scorer.id));
}
function scoreGoal(state, team, lineup, goals) {
  const scorer = attackingPlayer(lineup);
  const assister = Math.random() > .25 ? assistPlayer(lineup, scorer) : null;
  goals[team.id]++;
  const p = state.players.find(x => x.id === scorer.id); if (p) p.goals++;
  if (assister) { const a = state.players.find(x => x.id === assister.id); if (a) a.assists++; }
  return { scorer, assister };
}

export function simulateMatch(state, fixture, userTactic = 'balanced', cpuTactic = 'balanced') {
  const home = teamById(state, fixture.homeTeamId), away = teamById(state, fixture.awayTeamId);
  const homePlayers = playersByTeam(state, home.id), awayPlayers = playersByTeam(state, away.id);
  const homeLineup = selectLineup(state, home.id, homePlayers), awayLineup = selectLineup(state, away.id, awayPlayers);
  const tactics = { [home.id]: fixture.homeTeamId === state.selectedTeamId ? userTactic : cpuTactic, [away.id]: fixture.awayTeamId === state.selectedTeamId ? userTactic : cpuTactic };
  let hStr = teamStrength(homeLineup), aStr = teamStrength(awayLineup);
  hStr *= 1.04; // ev sahibi
  hStr *= 1 + tacticProfiles[tactics[home.id]].attack;
  aStr *= 1 + tacticProfiles[tactics[away.id]].attack;
  const totalTempo = (tacticProfiles[tactics[home.id]].tempo + tacticProfiles[tactics[away.id]].tempo) / 2;
  const goals = { [home.id]: 0, [away.id]: 0 };
  const events = [{ minute: 0, type: 'normal', text: `${home.name} - ${away.name} başladı. ${home.name}: ${tacticProfiles[tactics[home.id]].label}, ${away.name}: ${tacticProfiles[tactics[away.id]].label}.` }];
  const eventMinutes = [6,12,18,24,31,38,44,51,58,64,70,76,82,88];
  for (const minute of eventMinutes) {
    const energyDropH = 1 - Math.max(0, minute - 60) * .0028 * tacticProfiles[tactics[home.id]].drain;
    const energyDropA = 1 - Math.max(0, minute - 60) * .0028 * tacticProfiles[tactics[away.id]].drain;
    const currentH = hStr * energyDropH;
    const currentA = aStr * energyDropA;
    const chanceVolume = clamp(((currentH + currentA) / 155) * .22 * totalTempo, .12, .34);
    const homeProb = currentH / (currentH + currentA);
    if (Math.random() < chanceVolume) {
      const team = Math.random() < homeProb ? home : away;
      const lineup = team.id === home.id ? homeLineup : awayLineup;
      const xg = clamp((team.id === home.id ? currentH - currentA : currentA - currentH) / 70 + .24, .13, .42);
      if (Math.random() < xg) {
        const { scorer, assister } = scoreGoal(state, team, lineup, goals);
        events.push(goalEvent(minute, team, scorer, assister));
      } else {
        events.push(normalEvent(minute, team, attackingPlayer(lineup)));
      }
    } else if (Math.random() < .48) {
      const team = Math.random() < homeProb ? home : away;
      events.push(normalEvent(minute, team, attackingPlayer(team.id === home.id ? homeLineup : awayLineup)));
    }
    if (minute === 70 && (tactics[home.id] === 'high' || tactics[away.id] === 'high')) {
      events.push(fatigueEvent(minute, tactics[home.id] === 'high' ? home : away));
    }
    const cardChance = .035 * totalTempo;
    if (Math.random() < cardChance) {
      const cardTeam = Math.random() < homeProb ? away : home;
      const cardLineup = cardTeam.id === home.id ? homeLineup : awayLineup;
      const player = choice(cardLineup);
      const real = state.players.find(x => x.id === player.id);
      if (real) real.yellowCards = (real.yellowCards || 0) + 1;
      events.push({ minute, type: 'card', playerId: player.id, text: `${player.name} geç müdahale sonrası sarı kart gördü.` });
    }
  }
  // enerji, dakika, sakatlık
  for (const p of [...homeLineup, ...awayLineup]) {
    const tactic = p.teamId === home.id ? tactics[home.id] : tactics[away.id];
    const real = state.players.find(x => x.id === p.id);
    if (!real) continue;
    real.minutes += 90;
    drainPlayerEnergy(real, tactic, 90);
    real.form = clamp(real.form + rand(-.18, .22) + (goals[p.teamId] > goals[p.teamId === home.id ? away.id : home.id] ? .05 : -.03), 4.5, 9.4);
    const injChance = .006 * tacticProfiles[tactic].injury * (1.15 - real.durability/120);
    if (Math.random() < injChance) {
      real.injuredWeeks = Math.ceil(rand(1, 4));
      events.push(injuryEvent(Math.floor(rand(20, 88)), real));
    }
  }
  events.sort((a,b) => a.minute - b.minute);
  fixture.played = true;
  fixture.result = { home: goals[home.id], away: goals[away.id] };
  fixture.events = events;
  state.lastMatch = { fixtureId: fixture.id, homeTeamId: home.id, awayTeamId: away.id, result: fixture.result, events };
  return fixture;
}
