import { clamp, rand } from '../core/utils.js';
export const tacticProfiles = {
  low: { label: 'Az Baskı', drain: .72, attack: -.05, defense: .05, injury: .75, tempo: .85 },
  balanced: { label: 'Dengeli', drain: 1, attack: 0, defense: 0, injury: 1, tempo: 1 },
  high: { label: 'Çok Baskılı', drain: 1.38, attack: .09, defense: -.04, injury: 1.25, tempo: 1.18 }
};
export function drainPlayerEnergy(player, tacticKey, minutes = 90) {
  const profile = tacticProfiles[tacticKey] || tacticProfiles.balanced;
  const durabilityProtection = player.durability / 100;
  const loss = (minutes / 90) * profile.drain * rand(12, 20) * (1.15 - durabilityProtection * .35);
  player.energy = clamp(Math.round(player.energy - loss), 1, 110);
}
export function recoverWeeklyEnergy(player, matchesThisWeek = 1) {
  if (player.injuredWeeks > 0) {
    player.injuredWeeks--;
    player.energy = clamp(player.energy + 8, 1, 110);
    return;
  }
  const maxEnergy = 92 + Math.round(player.durability * .18);
  const recovery = 12 + Math.round(player.durability * .16) - Math.max(0, matchesThisWeek - 1) * 5;
  player.energy = clamp(player.energy + recovery, 1, maxEnergy);
}
