export const $ = (selector) => document.querySelector(selector);
export const app = () => document.querySelector('#app');
export function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }
export function rand(min = 0, max = 1) { return Math.random() * (max - min) + min; }
export function choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
export function deepClone(obj) { return JSON.parse(JSON.stringify(obj)); }
export function fmtDate(ts) { return new Date(ts).toLocaleString('tr-TR'); }
export function teamById(state, id) { return state.teams.find(t => t.id === id); }
export function playersByTeam(state, teamId) { return state.players.filter(p => p.teamId === teamId); }
export function avg(arr) { return arr.length ? arr.reduce((a,b)=>a+b,0) / arr.length : 0; }
