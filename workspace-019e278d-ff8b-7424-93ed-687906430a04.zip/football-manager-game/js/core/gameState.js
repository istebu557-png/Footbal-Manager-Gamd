import { teams, league, createDefaultPlayers } from '../data/defaultDatabase.js';
import { generateDoubleRoundRobin } from '../league/fixtureGenerator.js';
import { createEmptyTable } from '../league/tableSystem.js';
import { createDefaultLineups } from '../league/lineupSystem.js';
import { deepClone } from './utils.js';

export function createNewGame({ managerName, selectedTeamId, slot }) {
  const clonedTeams = deepClone(teams);
  const players = createDefaultPlayers();
  return {
    version: '0.2',
    slot,
    managerName: managerName || 'Menajer',
    selectedTeamId,
    currentWeek: 1,
    maxWeek: (clonedTeams.length - 1) * 2,
    league: deepClone(league),
    teams: clonedTeams,
    players,
    fixtures: generateDoubleRoundRobin(clonedTeams.map(t => t.id)),
    table: createEmptyTable(clonedTeams),
    lineups: createDefaultLineups(clonedTeams, players),
    news: [`Kariyer başladı. ${league.name} fikstürü açıklandı.`],
    lastMatch: null
  };
}
