const PREFIX = 'wsc_like_career_slot_';
export function saveGame(slot, state) {
  const payload = { version: '0.1', savedAt: Date.now(), state };
  localStorage.setItem(PREFIX + slot, JSON.stringify(payload));
}
export function loadGame(slot) {
  const raw = localStorage.getItem(PREFIX + slot);
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}
export function deleteSave(slot) { localStorage.removeItem(PREFIX + slot); }
export function listSaves() {
  return [1,2,3].map(slot => ({ slot, payload: loadGame(slot) }));
}
