export function generateDoubleRoundRobin(teamIds) {
  const teams = [...teamIds];
  if (teams.length % 2) teams.push('BYE');
  const n = teams.length;
  const rounds = [];
  let arr = [...teams];
  for (let r = 0; r < n - 1; r++) {
    const matches = [];
    for (let i = 0; i < n / 2; i++) {
      const a = arr[i], b = arr[n - 1 - i];
      if (a !== 'BYE' && b !== 'BYE') {
        const flip = r % 2 === 0;
        matches.push({ homeTeamId: flip ? a : b, awayTeamId: flip ? b : a });
      }
    }
    rounds.push(matches);
    arr = [arr[0], arr[n - 1], ...arr.slice(1, n - 1)];
  }
  const fixtures = [];
  let id = 1;
  rounds.forEach((matches, idx) => {
    matches.forEach((m, order) => fixtures.push({
      id: `L${id++}`,
      competition: 'league',
      week: idx + 1,
      day: order < 2 ? 'Cumartesi' : 'Pazar',
      ...m,
      played: false,
      result: null,
      events: []
    }));
  });
  rounds.forEach((matches, idx) => {
    matches.forEach((m, order) => fixtures.push({
      id: `L${id++}`,
      competition: 'league',
      week: idx + 1 + rounds.length,
      day: order < 2 ? 'Cumartesi' : 'Pazar',
      homeTeamId: m.awayTeamId,
      awayTeamId: m.homeTeamId,
      played: false,
      result: null,
      events: []
    }));
  });
  return fixtures;
}
