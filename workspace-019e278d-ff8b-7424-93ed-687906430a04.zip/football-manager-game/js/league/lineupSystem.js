export const POSITION_ORDER = { GK: 1, RB: 2, LB: 3, FB: 3, CB: 4, DM: 5, CM: 6, AM: 7, RW: 8, LW: 9, W: 9, ST: 10 };

export function bestEleven(players) {
  const healthy = players.filter(p => p.injuredWeeks <= 0);
  const sorted = [...healthy].sort((a,b) => b.overall - a.overall);
  const pick = [];
  function take(posList, count) {
    for (const p of sorted) {
      if (pick.length >= 11) break;
      if (pick.includes(p)) continue;
      if (posList.includes(p.position) && pick.filter(x => posList.includes(x.position)).length < count) pick.push(p);
    }
  }
  take(['GK'], 1);
  take(['CB'], 2);
  take(['RB','LB','FB'], 2);
  take(['DM','CM'], 3);
  take(['AM','RW','LW','W'], 2);
  take(['ST'], 1);
  for (const p of sorted) if (pick.length < 11 && !pick.includes(p)) pick.push(p);
  return pick.slice(0, 11).map(p => p.id);
}

export function createDefaultLineups(teams, players) {
  const lineups = {};
  for (const t of teams) lineups[t.id] = bestEleven(players.filter(p => p.teamId === t.id));
  return lineups;
}

export function normalizeLineup(teamPlayers, selectedIds) {
  const valid = new Set(teamPlayers.filter(p => p.injuredWeeks <= 0).map(p => p.id));
  const clean = [...new Set(selectedIds || [])].filter(id => valid.has(id));
  if (clean.length >= 11) return clean.slice(0, 11);
  const auto = bestEleven(teamPlayers);
  for (const id of auto) if (clean.length < 11 && !clean.includes(id)) clean.push(id);
  return clean.slice(0, 11);
}
