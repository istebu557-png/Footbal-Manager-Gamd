export function createEmptyTable(teams) {
  return teams.map(t => ({ teamId: t.id, P:0, W:0, D:0, L:0, GF:0, GA:0, GD:0, Pts:0, form: [] }));
}
export function applyResult(table, match) {
  const h = table.find(r => r.teamId === match.homeTeamId);
  const a = table.find(r => r.teamId === match.awayTeamId);
  const hg = match.result.home, ag = match.result.away;
  h.P++; a.P++; h.GF += hg; h.GA += ag; a.GF += ag; a.GA += hg;
  h.GD = h.GF - h.GA; a.GD = a.GF - a.GA;
  if (hg > ag) { h.W++; a.L++; h.Pts += 3; h.form.push('W'); a.form.push('L'); }
  else if (ag > hg) { a.W++; h.L++; a.Pts += 3; a.form.push('W'); h.form.push('L'); }
  else { h.D++; a.D++; h.Pts++; a.Pts++; h.form.push('D'); a.form.push('D'); }
  h.form = h.form.slice(-5); a.form = a.form.slice(-5);
}
export function sortTable(table) {
  return [...table].sort((a,b) => b.Pts-a.Pts || b.GD-a.GD || b.GF-a.GF || a.teamId.localeCompare(b.teamId));
}
