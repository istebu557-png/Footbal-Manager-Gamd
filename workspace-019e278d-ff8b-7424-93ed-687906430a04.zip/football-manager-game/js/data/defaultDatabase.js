const firstNames = ["Arda","Mert","Kerem","Emir","Deniz","Umut","Efe","Kaan","Yusuf","Can","Burak","Ozan","Ali","Cem","Tuna","Baran","Milan","Lucas","Diego","Jonas","Nico","Ivan","Marco","Leo"];
const lastNames = ["Yılmaz","Kaya","Demir","Şahin","Çelik","Aydın","Koç","Arslan","Öztürk","Kurt","Aksoy","Güneş","Silva","Costa","Rossi","Müller","Garcia","Santos","Novak","Petrov"];
const positions = ["GK","RB","CB","CB","LB","DM","CM","AM","RW","LW","ST","GK","CB","FB","CM","AM","W","ST"];

export const teams = [
  { id: "istanbul_aslan", name: "İstanbul Aslan", shortName: "İAS", city: "İstanbul", reputation: 86, colors: ["#ffbf00", "#a30b1a"] },
  { id: "kadikoy_firtina", name: "Kadıköy Fırtına", shortName: "KDF", city: "İstanbul", reputation: 84, colors: ["#fff200", "#103d8c"] },
  { id: "besiktas_kartal", name: "Beşiktaş Kartal", shortName: "BJK", city: "İstanbul", reputation: 82, colors: ["#ffffff", "#111111"] },
  { id: "trabzon_deniz", name: "Trabzon Deniz", shortName: "TRD", city: "Trabzon", reputation: 79, colors: ["#7a1230", "#47a7d8"] },
  { id: "bursa_yesil", name: "Bursa Yeşil", shortName: "BYS", city: "Bursa", reputation: 73, colors: ["#0b8f4d", "#ffffff"] },
  { id: "ankara_baskent", name: "Ankara Başkent", shortName: "ANK", city: "Ankara", reputation: 72, colors: ["#e43d30", "#111111"] },
  { id: "izmir_korfez", name: "İzmir Körfez", shortName: "IZM", city: "İzmir", reputation: 71, colors: ["#1f65ff", "#e02a2a"] },
  { id: "antalya_gunes", name: "Antalya Güneş", shortName: "ANT", city: "Antalya", reputation: 70, colors: ["#e21b2d", "#ffffff"] },
  { id: "konya_ova", name: "Konya Ova", shortName: "KON", city: "Konya", reputation: 68, colors: ["#168a4a", "#ffffff"] },
  { id: "adana_akdeniz", name: "Adana Akdeniz", shortName: "ADA", city: "Adana", reputation: 69, colors: ["#f36b21", "#0b4aa2"] }
];

function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }
function seededValue(seed) {
  const x = Math.sin(seed * 999.13) * 10000;
  return x - Math.floor(x);
}

export function createDefaultPlayers() {
  const players = [];
  let id = 1;
  teams.forEach((team, tIndex) => {
    const base = team.reputation - 8;
    positions.forEach((pos, pIndex) => {
      const seed = (tIndex + 1) * 100 + pIndex + 1;
      const age = 18 + Math.floor(seededValue(seed) * 17);
      const overall = clamp(Math.round(base + 2 + seededValue(seed + 1) * 16 - (pIndex > 10 ? 4 : 0)), 55, 92);
      const potential = clamp(overall + Math.round(seededValue(seed + 2) * (age < 23 ? 12 : 6)), overall, 97);
      const name = `${firstNames[(seed + pIndex) % firstNames.length]} ${lastNames[(seed + tIndex) % lastNames.length]}`;
      players.push({
        id: `p_${id++}`,
        name,
        age,
        nationality: seededValue(seed + 3) > .78 ? ["Brezilya","Sırbistan","Fransa","Almanya","Nijerya"][Math.floor(seededValue(seed + 4)*5)] : "Türkiye",
        position: pos,
        teamId: team.id,
        overall,
        potential,
        dynamicPotential: potential,
        pace: clamp(Math.round(overall - 5 + seededValue(seed + 5) * 18), 40, 96),
        shooting: clamp(Math.round(overall - (pos === "GK" ? 35 : 8) + seededValue(seed + 6) * 18), 20, 96),
        passing: clamp(Math.round(overall - 6 + seededValue(seed + 7) * 16), 35, 96),
        dribbling: clamp(Math.round(overall - 6 + seededValue(seed + 8) * 16), 35, 96),
        physical: clamp(Math.round(overall - 6 + seededValue(seed + 9) * 16), 35, 96),
        durability: clamp(Math.round(58 + seededValue(seed + 10) * 35), 45, 96),
        energy: 100,
        form: 6.8 + seededValue(seed + 11) * .8,
        morale: 65 + Math.round(seededValue(seed + 12) * 25),
        goals: 0,
        assists: 0,
        yellowCards: 0,
        redCards: 0,
        minutes: 0,
        injuredWeeks: 0
      });
    });
  });
  return players;
}

export const league = {
  id: "test_super_lig",
  name: "Test Süper Lig",
  country: "Türkiye",
  season: "2025/26"
};
