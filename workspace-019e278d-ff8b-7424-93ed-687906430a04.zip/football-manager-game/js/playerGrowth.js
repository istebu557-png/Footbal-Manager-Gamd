import { clamp } from './core/utils.js';
export function weeklyGrowth(players) {
  for (const p of players) {
    if (p.age <= 23 && p.minutes > 0 && Math.random() < .05) {
      const limit = p.dynamicPotential || p.potential;
      if (p.overall < limit) p.overall = clamp(p.overall + 1, 40, 99);
    }
    if (p.age <= 21 && p.form >= 7.4 && Math.random() < .035) p.dynamicPotential = clamp((p.dynamicPotential || p.potential) + 1, p.overall, 99);
    if (p.injuredWeeks > 0 && Math.random() < .02) p.dynamicPotential = clamp((p.dynamicPotential || p.potential) - 1, p.overall, 99);
  }
}
