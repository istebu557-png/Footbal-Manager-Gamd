import { app, fmtDate, playersByTeam, teamById } from './core/utils.js';
import { createNewGame } from './core/gameState.js';
import { saveGame, loadGame, deleteSave, listSaves } from './core/saveSystem.js';
import { sortTable, applyResult } from './league/tableSystem.js';
import { createDefaultLineups, normalizeLineup, POSITION_ORDER } from './league/lineupSystem.js';
import { simulateMatch } from './match/matchEngine.js';
import { recoverWeeklyEnergy } from './match/energyEngine.js';
import { effectiveRating } from './match/ratingEngine.js';
import { weeklyGrowth } from './playerGrowth.js';
import { teams as defaultTeams } from './data/defaultDatabase.js';

let state = null;
let currentView = 'menu';

function setHTML(html) { app().innerHTML = html; }
function escapeHtml(str='') { return String(str).replace(/[&<>'"]/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[s])); }
function teamName(id) { return teamById(state, id)?.name || id; }
function selectedTeam() { return teamById(state, state.selectedTeamId); }
function migrateState(loaded) {
  if (!loaded) return loaded;
  loaded.version = loaded.version || '0.1';
  if (!loaded.lineups) loaded.lineups = createDefaultLineups(loaded.teams, loaded.players);
  for (const t of loaded.teams) loaded.lineups[t.id] = normalizeLineup(loaded.players.filter(p => p.teamId === t.id), loaded.lineups[t.id]);
  for (const p of loaded.players) {
    p.yellowCards = p.yellowCards || 0; p.redCards = p.redCards || 0;
    p.dynamicPotential = p.dynamicPotential || p.potential;
  }
  return loaded;
}

function shell(content) {
  const club = selectedTeam();
  return `
    <div class="topbar">
      <div class="brand"><b>${club?.name || 'Kariyer'}</b><span>${state.league.name} • Hafta ${state.currentWeek}/${state.maxWeek} • Slot ${state.slot}</span></div>
      <div class="nav">
        <button class="secondary" data-nav="dashboard">Ana ekran</button>
        <button class="secondary" data-nav="squad">Kadro</button>
        <button class="secondary" data-nav="lineup">İlk 11</button>
        <button class="secondary" data-nav="fixtures">Fikstür</button>
        <button class="secondary" data-nav="table">Puan durumu</button>
        <button class="secondary" data-nav="stats">Krallıklar</button>
        <button class="secondary" data-nav="menu">Menü</button>
      </div>
    </div>
    ${content}
  `;
}
function bindShellNav() {
  document.querySelectorAll('[data-nav]').forEach(btn => btn.addEventListener('click', () => {
    const v = btn.dataset.nav;
    if (v === 'menu') renderMenu(); else renderCareer(v);
  }));
}

function renderMenu() {
  currentView = 'menu';
  const saves = listSaves();
  setHTML(`
    <section class="hero">
      <div class="card">
        <h1 class="title">WSC Tarzı<br>Futbol Kariyeri <span class="ok">v0.2</span></h1>
        <p class="subtitle">v0.2: 10 takımlı test ligi, 3 kayıt slotu, ilk 11 seçimi, fikstür, puan durumu, gol/asist krallığı, enerji/durability ve yazılı maç simülasyonu.</p>
      </div>
      <div class="grid three">
        ${saves.map(({slot, payload}) => `
          <div class="card slot">
            <div>
              <h2>Slot ${slot}</h2>
              ${payload ? `
                <p><b>${escapeHtml(payload.state.managerName)}</b> • ${escapeHtml(teamById(payload.state, payload.state.selectedTeamId)?.name || '')}</p>
                <p class="muted">Hafta ${payload.state.currentWeek}/${payload.state.maxWeek}</p>
                <p class="muted small">Son kayıt: ${fmtDate(payload.savedAt)}</p>
              ` : `<p class="muted">Boş kayıt slotu.</p>`}
            </div>
            <div class="kpi">
              ${payload ? `<button data-load="${slot}">Devam et</button><button class="danger" data-delete="${slot}">Sil</button>` : ''}
              <button class="secondary" data-new="${slot}">${payload ? 'Yeni kariyer kur' : 'Yeni kariyer'}</button>
            </div>
          </div>
        `).join('')}
      </div>
    </section>
  `);
  document.querySelectorAll('[data-load]').forEach(b => b.onclick = () => { state = migrateState(loadGame(b.dataset.load).state); saveGame(state.slot, state); renderCareer('dashboard'); });
  document.querySelectorAll('[data-delete]').forEach(b => b.onclick = () => { if (confirm('Bu kayıt silinsin mi?')) { deleteSave(b.dataset.delete); renderMenu(); } });
  document.querySelectorAll('[data-new]').forEach(b => b.onclick = () => renderNewCareer(Number(b.dataset.new)));
}

function renderNewCareer(slot) {
  let selected = defaultTeams[0].id;
  setHTML(`
    <div class="card">
      <h1>Yeni Kariyer - Slot ${slot}</h1>
      <p class="muted">v0.2 için kurgusal test ligi kullanılıyor. Sonraki sürümlerde Süper Lig, 5 büyük lig, Avrupa kupaları ve veri içe aktarma eklenebilir.</p>
      <label>Menajer adı</label><br>
      <input id="managerName" value="Menajer" style="margin:8px 0 18px;padding:12px;border-radius:12px;border:1px solid var(--line);background:#0d1b2b;color:white;width:min(360px,100%)" />
      <h2>Takım seç</h2>
      <div class="grid two">
        ${defaultTeams.map((t, i) => `
          <div class="card team-card ${i===0?'selected':''}" data-team="${t.id}">
            <div class="kpi"><span class="pill"><strong>${t.shortName}</strong></span><span class="pill">Rep <strong>${t.reputation}</strong></span></div>
            <h3>${t.name}</h3><p class="muted">${t.city}</p>
          </div>
        `).join('')}
      </div>
      <div class="kpi" style="margin-top:16px"><button id="startCareer">Kariyeri Başlat</button><button class="secondary" id="backMenu">Geri</button></div>
    </div>
  `);
  document.querySelectorAll('[data-team]').forEach(c => c.onclick = () => {
    document.querySelectorAll('.team-card').forEach(x => x.classList.remove('selected'));
    c.classList.add('selected'); selected = c.dataset.team;
  });
  document.querySelector('#backMenu').onclick = renderMenu;
  document.querySelector('#startCareer').onclick = () => {
    const managerName = document.querySelector('#managerName').value.trim() || 'Menajer';
    state = createNewGame({ managerName, selectedTeamId: selected, slot });
    saveGame(slot, state);
    renderCareer('dashboard');
  };
}

function renderCareer(view = 'dashboard') {
  currentView = view;
  if (view === 'dashboard') return renderDashboard();
  if (view === 'squad') return renderSquad();
  if (view === 'fixtures') return renderFixtures();
  if (view === 'table') return renderTable();
  if (view === 'lineup') return renderLineup();
  if (view === 'stats') return renderStats();
}

function weeklyFixtures() { return state.fixtures.filter(f => f.week === state.currentWeek); }
function selectedMatchThisWeek() { return weeklyFixtures().find(f => !f.played && (f.homeTeamId === state.selectedTeamId || f.awayTeamId === state.selectedTeamId)); }

function renderDashboard() {
  const match = selectedMatchThisWeek();
  const weekMatches = weeklyFixtures();
  const rank = sortTable(state.table).findIndex(r => r.teamId === state.selectedTeamId) + 1;
  const squad = playersByTeam(state, state.selectedTeamId);
  const avgEnergy = Math.round(squad.reduce((a,p)=>a+p.energy,0)/squad.length);
  setHTML(shell(`
    <div class="grid two">
      <div class="card">
        <h1>Hafta ${state.currentWeek}</h1>
        <div class="kpi">
          <span class="pill">Sıra <strong>${rank || '-'}</strong></span>
          <span class="pill">Ortalama enerji <strong>${avgEnergy}%</strong></span>
          <span class="pill">Maç sayısı <strong>${weekMatches.length}</strong></span>
        </div>
        <h2>Bu haftaki maçın</h2>
        ${match ? fixtureHTML(match, true) : `<p class="muted">Bu hafta oynanacak kullanıcı maçı yok veya maçın oynandı.</p>`}
        <div class="card" style="margin-top:14px;background:rgba(255,255,255,.04)">
          <h3>Taktik seçimi</h3>
          <p class="muted small">Çok baskı daha fazla pozisyon üretir ama enerjiyi ve sakatlık riskini artırır.</p>
          <select id="tactic"><option value="low">Az Baskı</option><option selected value="balanced">Dengeli</option><option value="high">Çok Baskılı</option></select>
          <button id="playMatch" ${match?'':'disabled'}>Maçı Oyna</button>
          <button class="secondary" id="finishWeek">Haftayı Bitir / Simüle Et</button>
        </div>
      </div>
      <div class="card">
        <h2>Haberler</h2>
        ${state.news.slice(-8).reverse().map(n => `<div class="event"><span class="minute">•</span>${escapeHtml(n)}</div>`).join('')}
      </div>
    </div>
    ${state.lastMatch ? `<div class="card" style="margin-top:16px"><h2>Son maç özeti</h2>${lastMatchSummary()}</div>` : ''}
  `));
  bindShellNav();
  document.querySelector('#playMatch').onclick = () => playUserMatch(match.id, document.querySelector('#tactic').value);
  document.querySelector('#finishWeek').onclick = finishWeek;
}

function playUserMatch(id, tactic) {
  const fixture = state.fixtures.find(f => f.id === id);
  simulateMatch(state, fixture, tactic, ['low','balanced','high'][Math.floor(Math.random()*3)]);
  applyResult(state.table, fixture);
  state.news.push(`${teamName(fixture.homeTeamId)} ${fixture.result.home}-${fixture.result.away} ${teamName(fixture.awayTeamId)} oynandı.`);
  saveGame(state.slot, state);
  renderMatchScreen(fixture);
}

function renderMatchScreen(fixture) {
  setHTML(shell(`
    <div class="match-layout">
      <div class="card scoreboard">
        <div class="muted">${state.league.name} • Hafta ${fixture.week}</div>
        <h2>${teamName(fixture.homeTeamId)}<br><span class="muted">vs</span><br>${teamName(fixture.awayTeamId)}</h2>
        <div class="scoreline">${fixture.result.home} - ${fixture.result.away}</div>
        <button id="backDash">Ana ekrana dön</button>
      </div>
      <div class="card">
        <h2>Profesyonel Yazılı Maç Ekranı</h2>
        <div class="commentary">
          ${fixture.events.map(e => `<div class="event ${e.type === 'goal' ? 'goal' : e.type === 'injury' ? 'injury' : e.type === 'card' ? 'cardEvent' : ''}"><span class="minute">${e.minute}'</span>${escapeHtml(e.text)}</div>`).join('')}
        </div>
      </div>
    </div>
  `));
  bindShellNav();
  document.querySelector('#backDash').onclick = () => renderDashboard();
}

function simulateRemainingWeek() {
  for (const f of weeklyFixtures().filter(x => !x.played)) {
    simulateMatch(state, f, 'balanced', ['low','balanced','high'][Math.floor(Math.random()*3)]);
    applyResult(state.table, f);
  }
}
function finishWeek() {
  simulateRemainingWeek();
  weeklyGrowth(state.players);
  // v0.1 tek lig olduğu için her oyuncuya haftalık recovery veriyoruz.
  for (const p of state.players) recoverWeeklyEnergy(p, 1);
  saveGame(state.slot, state);
  state.news.push(`Hafta ${state.currentWeek} tamamlandı. Otomatik kayıt alındı.`);
  if (state.currentWeek < state.maxWeek) state.currentWeek++;
  else { const champ = sortTable(state.table)[0]; state.news.push(`Sezon tamamlandı. Şampiyon: ${teamName(champ.teamId)}!`); }
  saveGame(state.slot, state);
  renderDashboard();
}

function fixtureHTML(f, compact = false) {
  return `<div class="fixture">
    <div class="home">${teamName(f.homeTeamId)}</div>
    <div class="score">${f.played ? `${f.result.home}-${f.result.away}` : 'v'}</div>
    <div class="away">${teamName(f.awayTeamId)}</div>
    <div class="muted small">${f.day}</div>
  </div>`;
}
function renderFixtures() {
  const weeks = Array.from({length: state.maxWeek}, (_, i) => i + 1);
  setHTML(shell(`
    <div class="card"><h1>Fikstür</h1><p class="muted">Lig çift devreli fikstür. Haftalar halinde ayrılmıştır.</p></div>
    ${weeks.map(w => `<div class="card" style="margin-top:14px"><h2>Hafta ${w}</h2><div class="grid">${state.fixtures.filter(f=>f.week===w).map(fixtureHTML).join('')}</div></div>`).join('')}
  `));
  bindShellNav();
}
function renderTable() {
  const rows = sortTable(state.table);
  setHTML(shell(`
    <div class="card"><h1>Puan Durumu</h1><div class="table-wrap"><table><thead><tr><th>#</th><th>Takım</th><th>O</th><th>G</th><th>B</th><th>M</th><th>AG</th><th>YG</th><th>AV</th><th>P</th><th>Form</th></tr></thead><tbody>
    ${rows.map((r,i)=>`<tr><td>${i+1}</td><td><b>${teamName(r.teamId)}</b></td><td>${r.P}</td><td>${r.W}</td><td>${r.D}</td><td>${r.L}</td><td>${r.GF}</td><td>${r.GA}</td><td>${r.GD}</td><td><b>${r.Pts}</b></td><td>${r.form.join(' ')}</td></tr>`).join('')}
    </tbody></table></div></div>
  `));
  bindShellNav();
}
function renderSquad() {
  const squad = playersByTeam(state, state.selectedTeamId).sort((a,b)=> effectiveRating(b)-effectiveRating(a));
  setHTML(shell(`
    <div class="card">
      <h1>Kadro</h1>
      <p class="muted">Kart reytingi görünür; maç motoru arka planda enerji, form ve morale bağlı gizli dinamik reyting kullanır.</p>
      <div class="table-wrap"><table><thead><tr><th>Oyuncu</th><th>Yaş</th><th>Poz</th><th>OVR</th><th>Gizli maç reytingi</th><th>Hız</th><th>Şut</th><th>Pas</th><th>Drib.</th><th>Fizik</th><th>Pot.</th><th>Dur.</th><th>Enerji</th><th>G/A</th><th>Kart</th></tr></thead><tbody>
      ${squad.map(p => `<tr>
        <td><b>${escapeHtml(p.name)}</b><br><span class="muted small">${p.nationality}${p.injuredWeeks>0?` • <span class="dangerText">Sakat ${p.injuredWeeks} hf</span>`:''}</span></td>
        <td>${p.age}</td><td>${p.position}</td><td class="rating">${p.overall}</td><td>${effectiveRating(p)}</td><td>${p.pace}</td><td>${p.shooting}</td><td>${p.passing}</td><td>${p.dribbling}</td><td>${p.physical}</td><td>${p.dynamicPotential}</td><td>${p.durability}</td>
        <td><div class="energybar"><span style="width:${Math.min(100,p.energy)}%"></span></div><span class="small">${p.energy}%</span></td><td>${p.goals}/${p.assists}</td><td>${p.yellowCards || 0}/${p.redCards || 0}</td>
      </tr>`).join('')}
      </tbody></table></div>
    </div>
  `));
  bindShellNav();
}
function renderLineup() {
  const squad = playersByTeam(state, state.selectedTeamId).sort((a,b) => (POSITION_ORDER[a.position]||99)-(POSITION_ORDER[b.position]||99) || b.overall-a.overall);
  state.lineups[state.selectedTeamId] = normalizeLineup(squad, state.lineups[state.selectedTeamId]);
  const selected = new Set(state.lineups[state.selectedTeamId]);
  setHTML(shell(`
    <div class="card">
      <h1>İlk 11 Seçimi</h1>
      <p class="muted">Tam 11 oyuncu seç. Sakat oyuncular seçilemez. Kaydedilen ilk 11, maç motorunda direkt kullanılır.</p>
      <div class="kpi"><span class="pill">Seçili <strong id="selectedCount">${selected.size}</strong>/11</span><button id="autoLineup" class="secondary">Otomatik en iyi 11</button><button id="saveLineup">İlk 11'i Kaydet</button></div>
      <div class="table-wrap" style="margin-top:14px"><table><thead><tr><th>Seç</th><th>Oyuncu</th><th>Poz</th><th>OVR</th><th>Maç Reytingi</th><th>Enerji</th><th>Dur.</th><th>Form</th></tr></thead><tbody>
      ${squad.map(p => `<tr>
        <td><input type="checkbox" class="lineupCheck" data-id="${p.id}" ${selected.has(p.id)?'checked':''} ${p.injuredWeeks>0?'disabled':''}></td>
        <td><b>${escapeHtml(p.name)}</b><br><span class="muted small">${p.injuredWeeks>0?`Sakat ${p.injuredWeeks} hf`:p.nationality}</span></td>
        <td>${p.position}</td><td class="rating">${p.overall}</td><td>${effectiveRating(p)}</td>
        <td><div class="energybar"><span style="width:${Math.min(100,p.energy)}%"></span></div><span class="small">${p.energy}%</span></td><td>${p.durability}</td><td>${p.form.toFixed(1)}</td>
      </tr>`).join('')}
      </tbody></table></div>
    </div>
  `));
  bindShellNav();
  const checks = [...document.querySelectorAll('.lineupCheck')];
  const update = () => { document.querySelector('#selectedCount').textContent = checks.filter(c=>c.checked).length; };
  checks.forEach(c => c.addEventListener('change', () => { if (checks.filter(x=>x.checked).length > 11) c.checked = false; update(); }));
  document.querySelector('#autoLineup').onclick = () => { state.lineups[state.selectedTeamId] = normalizeLineup(squad, []); saveGame(state.slot, state); renderLineup(); };
  document.querySelector('#saveLineup').onclick = () => {
    const ids = checks.filter(c=>c.checked).map(c=>c.dataset.id);
    if (ids.length !== 11) return alert('Tam 11 oyuncu seçmelisin.');
    state.lineups[state.selectedTeamId] = ids;
    state.news.push('İlk 11 güncellendi.');
    saveGame(state.slot, state);
    renderDashboard();
  };
}

function renderStats() {
  const scorers = [...state.players].sort((a,b)=> (b.goals||0)-(a.goals||0) || (b.assists||0)-(a.assists||0)).slice(0, 20);
  const assisters = [...state.players].sort((a,b)=> (b.assists||0)-(a.assists||0) || (b.goals||0)-(a.goals||0)).slice(0, 20);
  const tableRows = (arr, mode) => arr.map((p,i)=>`<tr><td>${i+1}</td><td><b>${escapeHtml(p.name)}</b><br><span class="muted small">${teamName(p.teamId)} • ${p.position}</span></td><td>${p.goals||0}</td><td>${p.assists||0}</td><td>${p.yellowCards||0}</td><td>${p.overall}</td></tr>`).join('');
  setHTML(shell(`
    <div class="grid two">
      <div class="card"><h1>Gol Krallığı</h1><div class="table-wrap"><table><thead><tr><th>#</th><th>Oyuncu</th><th>Gol</th><th>Asist</th><th>Sarı</th><th>OVR</th></tr></thead><tbody>${tableRows(scorers,'g')}</tbody></table></div></div>
      <div class="card"><h1>Asist Krallığı</h1><div class="table-wrap"><table><thead><tr><th>#</th><th>Oyuncu</th><th>Gol</th><th>Asist</th><th>Sarı</th><th>OVR</th></tr></thead><tbody>${tableRows(assisters,'a')}</tbody></table></div></div>
    </div>
  `));
  bindShellNav();
}

function lastMatchSummary() {
  const lm = state.lastMatch;
  return `<div class="fixture"><div class="home">${teamName(lm.homeTeamId)}</div><div class="score">${lm.result.home}-${lm.result.away}</div><div class="away">${teamName(lm.awayTeamId)}</div><div></div></div>`;
}

renderMenu();
